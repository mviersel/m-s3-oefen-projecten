<template>
  <div class="flex flex-col items-center min-h-screen">
    <ProgressBar />
  </div>
</template>

<script>
import ProgressBar from '@/components/ProgressBar.vue'; 

export default {
  components: {
    ProgressBar
  }
};
</script>

<style scoped></style>
