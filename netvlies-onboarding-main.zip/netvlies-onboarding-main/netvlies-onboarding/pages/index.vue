<template>
  <div>
    <h1 class="">Home pagina</h1>
    <ButtonSet />

  </div>
</template>

<script setup></script>

<style lang="css" scoped></style>
