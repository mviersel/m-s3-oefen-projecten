<template>
  <div><p>Account pagina</p></div>
</template>

<script setup></script>

<style lang="css" scoped></style>
